EXTRA STEPS:
============


Now that you have completed all the three levels.. 
You can try few of these as additional exercises.

- In level2, why don't you save the images the user adds 
  to local storage and use them in level3
- In level3, instead of using the images from img/gifts folder, 
  get the images from the web based on the gift description and 
  store them
- You could use ajax calls, get the images from flickr/google-images/instagram
